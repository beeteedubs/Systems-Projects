#ifndef KITTENS_H
#define KITTENS_H

#define search(x,y,z) search(x,y,z)
int search(int*arrary, int target, int size);

struct thread_vars{
    int* array;
    int target;
    int arrayLen;
    int* j;
};
#endif
